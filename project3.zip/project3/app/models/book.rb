class Book < ApplicationRecord
	belongs_to :subject
	validates_presence_of :title #the value of title should not null
   validates_numericality_of :price, :message=>"Error Message" # thr value of price field should be numeric
	
end
