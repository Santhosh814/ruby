class Subject < ApplicationRecord
has_many :books
end
